package com.sample.cachingservice.mapper;

import com.sample.cachingservice.dto.EntitiesDTO;
import com.sample.cachingservice.entites.Entities;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class EntityMapper {

    private final ModelMapper modelMapper;

    public EntityMapper() {
        this.modelMapper = new ModelMapper();
    }

    public EntitiesDTO toDTO(Entities entity) {
        System.out.println("Mapping Entity to DTO");
        return modelMapper.map(entity, EntitiesDTO.class);
    }

    public Entities toEntity(EntitiesDTO entityDTO) {
        System.out.println("Mapping DTO to Entity");
        return modelMapper.map(entityDTO, Entities.class);
    }

}
