package com.sample.cachingservice.controller;

import com.sample.cachingservice.controllers.CacheController;
import com.sample.cachingservice.dto.EntitiesDTO;
import com.sample.cachingservice.entites.Entities;
import com.sample.cachingservice.services.CacheService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.beans.factory.annotation.Autowired;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import static org.mockito.Mockito.when;

@WebMvcTest(CacheController.class)
class CacheControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private CacheService cacheService;

    @Test
    void testAddEntity() throws Exception {
        Entities entity = new Entities(1L, "Test Data");

        mockMvc.perform(post("/cache/add")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"id\":\"1\",\"data\":\"Test Data\"}"))
                .andExpect(status().isOk())
                .andExpect(content().string("Entity added to cache."));
    }

    @Test
    void testGetEntity() throws Exception {
        Entities entity = new Entities(1L, "Test Data");
        EntitiesDTO entityDTO = new EntitiesDTO(1L, "Test Data");
        when(cacheService.get(1L)).thenReturn(entityDTO);

        mockMvc.perform(get("/cache/get/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value("1"))
                .andExpect(jsonPath("$.data").value("Test Data"));
    }

    @Test
    void testRemoveEntity() throws Exception {
        mockMvc.perform(delete("/cache/remove/"+"1")
                        .contentType(MediaType.APPLICATION_JSON)
                        )
                .andExpect(status().isOk())
                .andExpect(content().string("Entity removed from cache and database."));
    }

    @Test
    void testClearCache() throws Exception {
        mockMvc.perform(post("/cache/clear"))
                .andExpect(status().isOk())
                .andExpect(content().string("Cache cleared."));
    }

    @Test
    void testRemoveAll() throws Exception {
        mockMvc.perform(delete("/cache/removeAll"))
                .andExpect(status().isOk())
                .andExpect(content().string("All entities removed from cache and database."));
    }
}
