package com.sample.cachingservice.controllers;

import com.sample.cachingservice.dto.EntitiesDTO;
import com.sample.cachingservice.entites.Entities;
import com.sample.cachingservice.services.CacheService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cache")
public class CacheController {

    private static final Logger logger = LoggerFactory.getLogger(CacheController.class);

    private final CacheService cacheService;

    public CacheController(CacheService cacheService) {
        this.cacheService = cacheService;
    }

    @PostMapping("/add")
    public ResponseEntity<String> add(@Valid @RequestBody EntitiesDTO entitiesDTO) {
        cacheService.add(entitiesDTO);
        logger.info("Entity with ID {} added via API.", entitiesDTO.getId());
        return ResponseEntity.ok("Entity added to cache.");
    }

    @DeleteMapping("/remove/{id}")
    public ResponseEntity<String> remove(@PathVariable Long id) {
        cacheService.remove(id);
        logger.info("Entity with ID {} removed via API.", id);
        return ResponseEntity.ok("Entity removed from cache and database.");
    }

    @DeleteMapping("/removeAll")
    public ResponseEntity<String> removeAll() {
        cacheService.removeAll();
        logger.info("All entities removed via API.");
        return ResponseEntity.ok("All entities removed from cache and database.");
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<EntitiesDTO> get(@PathVariable Long id) {
        EntitiesDTO entityDTO = cacheService.get(id);
        logger.info("Entity with ID {} retrieved via API.", id);
        return ResponseEntity.ok(entityDTO);
    }

    @PostMapping("/clear")
    public ResponseEntity<String> clear() {
        cacheService.clear();
        logger.info("Cache cleared via API.");
        return ResponseEntity.ok("Cache cleared.");
    }
}