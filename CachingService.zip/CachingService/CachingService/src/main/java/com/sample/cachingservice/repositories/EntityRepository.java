package com.sample.cachingservice.repositories;

import com.sample.cachingservice.entites.Entities;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EntityRepository extends JpaRepository<Entities, Long> {


}
