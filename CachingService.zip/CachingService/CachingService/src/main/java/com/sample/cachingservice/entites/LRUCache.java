package com.sample.cachingservice.entites;
import java.util.*;

public class LRUCache extends LinkedHashMap<Long, Entities> {
    private static final long serialVersionUID = 1L;
    private final int maxSize;

    public LRUCache(int maxSize) {
        super(maxSize, 0.75f, true); // Creating with 'true', as we use the map for access-order
        this.maxSize = maxSize;
    }

    @Override
    protected boolean removeEldestEntry(Map.Entry<Long, Entities> eldest) {
        return size() > maxSize;
    }
}
