package com.sample.cachingservice.services;

import com.sample.cachingservice.dto.EntitiesDTO;
import com.sample.cachingservice.entites.Entities;
import com.sample.cachingservice.entites.LRUCache;
import com.sample.cachingservice.exceptions.EntityNotFoundException;
import com.sample.cachingservice.mapper.EntityMapper;
import com.sample.cachingservice.repositories.EntityRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.lang.*;

@Service
//@RequiredArgsConstructor
public class CacheService {

    private static final Logger logger = LoggerFactory.getLogger(CacheService.class);

    private LRUCache cache;

    @Value("${cache.max.size}")
    private int maxSize;

    private final EntityRepository entityRepository;
    private final EntityMapper entityMapper;

    public CacheService(EntityRepository entityRepository, EntityMapper entityMapper) {
        this.entityRepository = entityRepository;
        this.entityMapper = entityMapper;
    }

    @PostConstruct
    public void init() {
        cache = new LRUCache(maxSize) {
            private static final long serialVersionUID = 1L;

            @Override
            protected boolean removeEldestEntry(Map.Entry<Long, Entities> eldest) {
                boolean shouldRemove = super.removeEldestEntry(eldest);
                if (shouldRemove) {
                    // Evict to database
                    logger.info("Evicting entity with ID {} to database.", eldest.getKey());
                    entityRepository.save(eldest.getValue());
                }
                return shouldRemove;
            }
        };
        logger.info("Cache initialized with max size {}", maxSize);
    }

    public void add(EntitiesDTO entityDTO) {
        if (entityDTO == null || entityDTO.getId() == null) {
            throw new IllegalArgumentException("EntityDTO or EntityDTO ID must not be null.");
        }
        Entities entity = entityMapper.toEntity(entityDTO);
        cache.put(entityDTO.getId(), entity);
        System.out.println("inside add" +cache);
        logger.info("Entity with ID {} added to cache.", entityDTO.getId());
    }

    public void remove(Long id) {
        if (id == null) {
            throw new IllegalArgumentException("Entity ID must not be null.");
        }
        cache.remove(id);
        entityRepository.deleteById(id);
        logger.info("Entity with ID {} removed from cache and database.", id);
    }

    public void removeAll() {
        cache.clear();
        entityRepository.deleteAll();
        logger.info("All entities removed from cache and database.");
    }

    public EntitiesDTO get(Long id) {

        if (id == null) {
            throw new IllegalArgumentException("Entity ID must not be null.");
        }
        System.out.println("inside get" +cache);
        Entities cachedEntity = cache.get(id);
        if (cachedEntity != null) {
            logger.info("Entity with ID {} retrieved from cache.", id);
            return entityMapper.toDTO(cachedEntity);
        } else {
            // getting from database
            Optional<Entities> entityOptional = entityRepository.findById(id);
            if (entityOptional.isPresent()) {
                logger.info("Entity with ID {} retrieved from database.", id);
                return entityMapper.toDTO(entityOptional.get());
            } else {
                logger.warn("Entity with ID {} not found.", id);
                throw new EntityNotFoundException(id);
            }
        }
    }

    public void clear() {
        cache.clear();
        logger.info("Cache cleared.");
    }
}
