package com.sample.cachingservice.cache;

import com.sample.cachingservice.dto.EntitiesDTO;
import com.sample.cachingservice.entites.Entities;
import com.sample.cachingservice.entites.LRUCache;
import com.sample.cachingservice.exceptions.EntityNotFoundException;
import com.sample.cachingservice.mapper.EntityMapper;
import com.sample.cachingservice.repositories.EntityRepository;
import com.sample.cachingservice.services.CacheService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CacheServiceTest {

    @Mock
    private EntityRepository entityRepository;

    @Mock
    private EntityMapper entityMapper;

    @Mock
    private LRUCache cache;

    @InjectMocks
    private CacheService cacheService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(cacheService, "maxSize", 2);
        cacheService.init();
    }

    @Test
    void testEntityMapperDirectly() {
        EntityMapper mapper = new EntityMapper();  // Create a real instance, not a mock
        EntitiesDTO dto = new EntitiesDTO(1L, "Test Data");
        Entities entity = mapper.toEntity(dto);
        assertNotNull(entity);
        System.out.println("Entity mapped: " + entity.getData());  // Should print if toEntity is called
    }

    @Test
    void testAddAndGetEntity() {
        EntitiesDTO entityDTO = new EntitiesDTO(1L, "Test Data");
        Entities entity = new Entities(1L, "Test Data");

        when(entityMapper.toEntity(entityDTO)).thenReturn(entity);
        when(entityMapper.toDTO(entity)).thenReturn(entityDTO);

        cacheService.add(entityDTO);
        EntitiesDTO retrievedEntityDTO = cacheService.get(1L);

        assertEquals("Test Data", retrievedEntityDTO.getData());
        verify(entityRepository, never()).findById(1L);
    }

    @Test
    void testEvictionToDatabase() {
        EntitiesDTO entityDTO = new EntitiesDTO(1L, "Data 1");
        EntitiesDTO entityDTO2 = new EntitiesDTO(2L, "Data 2");
        EntitiesDTO entityDTO3 = new EntitiesDTO(3L, "Data 3");

        Entities entity = new Entities(1L, "Data 1");
        when(entityMapper.toEntity(entityDTO)).thenReturn(entity);
        when(entityMapper.toDTO(entity)).thenReturn(entityDTO);

        Entities entity2 = new Entities(2L, "Data 2");
        when(entityMapper.toEntity(entityDTO2)).thenReturn(entity2);
        when(entityMapper.toDTO(entity2)).thenReturn(entityDTO2);

        Entities entity3 = new Entities(3L, "Data 3");
        when(entityMapper.toEntity(entityDTO3)).thenReturn(entity3);
        when(entityMapper.toDTO(entity3)).thenReturn(entityDTO3);

        cacheService.add(entityDTO);
        cacheService.add(entityDTO2);
        cacheService.add(entityDTO3); // This should evict entity1 to the database

        verify(entityRepository, times(1)).save(entity);

        // entity1 should not be in cache now
        assertThrows(EntityNotFoundException.class, () -> cacheService.get(1L));

        // Mock database return
        when(entityRepository.findById(1L)).thenReturn(Optional.of(entity));

        EntitiesDTO retrievedEntity = cacheService.get(1L);
        assertEquals("Data 1", retrievedEntity.getData());
    }

    @Test
    void testRemoveEntity() {
        EntitiesDTO entityDTO = new EntitiesDTO(1L, "Data 1");
        cacheService.add(entityDTO);

        cacheService.remove(1L);
        verify(entityRepository, times(1)).deleteById(1L);

        assertThrows(EntityNotFoundException.class, () -> cacheService.get(1L));
    }

    @Test
    void testClearCache() {
        EntitiesDTO entityDTO = new EntitiesDTO(1L, "Test Data");
        cacheService.add(entityDTO);

        cacheService.clear();
        assertThrows(EntityNotFoundException.class, () -> cacheService.get(1L));
    }

    @Test
    void testRemoveAll() {
        EntitiesDTO entityDTO = new EntitiesDTO(1L, "Test Data");
        cacheService.add(entityDTO);

        cacheService.removeAll();
        verify(entityRepository, times(1)).deleteAll();
        assertThrows(EntityNotFoundException.class, () -> cacheService.get(1L));
    }
}
